<td >
    <select id="remark" name="remark" class="form-control" style="width: 80px;" onchange="update_data(this.id,value ,<?php echo $row['id'];?>,<?php echo $row['class_id'];?>,'<?php echo $x ?>')">
        <option value="10" <?php if($row['remark']==10){ echo 'selected';} ?>>10</option>
        <option value="9" <?php if($row['remark']==9){ echo 'selected';} ?>>09</option>
        <option value="8" <?php if($row['remark']==8){ echo 'selected';} ?>>08</option>
        <option value="7" <?php if($row['remark']==7){ echo 'selected';} ?>>07</option>
        <option value="6" <?php if($row['remark']==6){ echo 'selected';} ?>>06</option>
        <option value="5" <?php if($row['remark']==5){ echo 'selected';} ?>>05</option>
        <option value="4" <?php if($row['remark']==4){ echo 'selected';} ?>>04</option>
        <option value="3" <?php if($row['remark']==3){ echo 'selected';} ?>>03</option>
        <option value="2" <?php if($row['remark']==2){ echo 'selected';} ?>>02</option>
        <option value="1" <?php if($row['remark']==1){ echo 'selected';} ?>>01</option>
    </select>
</td>

<td >
    <select id="remark" name="remark" class="form-control" style="width: 80px;" onchange="update_data(this.id,value ,<?php echo $row['id'];?>,<?php echo $row['class_id'];?>,'<?php echo $x ?>')">
        <option value="1" <?php if($row['remark']==1){ echo 'selected';} ?>>01</option>
        <option value="2" <?php if($row['remark']==2){ echo 'selected';} ?>>02</option>
        <option value="3" <?php if($row['remark']==3){ echo 'selected';} ?>>03</option>
        <option value="4" <?php if($row['remark']==4){ echo 'selected';} ?>>04</option>
        <option value="5" <?php if($row['remark']==5){ echo 'selected';} ?>>05</option>
        <option value="6" <?php if($row['remark']==6){ echo 'selected';} ?>>06</option>
        <option value="7" <?php if($row['remark']==7){ echo 'selected';} ?>>07</option>
        <option value="8" <?php if($row['remark']==8){ echo 'selected';} ?>>08</option>
        <option value="9" <?php if($row['remark']==9){ echo 'selected';} ?>>09</option>
        <option value="10" <?php if($row['remark']==10){ echo 'selected';} ?>>10</option>
    </select>
</td>