<table class="table table-responsive">
    <tr><th>Id</th><td>. $row['employee_id'] .</tr>
    <tr><th>Employee No</th><td>. $row['emp_no'] .</tr>
    <tr><th>Name</th><td>. $row['name'] .</td></tr>
    <tr><th>Father's Name</th><td>. $row['father_name'] .</td></tr>
    <tr><th>Gender</th><td>. $row['gender'] .</td></tr>
    <tr><th>Date of Birth</th><td>. $row['dob'] .</td></tr>
    <tr><th>Joining Date</th><td>. $row['joining_date'] .</td></tr>
    <tr><th>Contact No</th><td>. $row['contact_no'] .</td></tr>
    <tr><th>Email</th><td>. $row['email'] .</td></tr>
    <tr><th>Emergency person</th><td>. $row['emergency_person'] .</td></tr>
    <tr><th>Emergency Contact No</th><td>. $row['emergency_contact_no'] .</td></tr>
    <tr><th>Addhar No</th><td>. $row['adhar_no'] .</td></tr>
    <tr><th>Pan No</th><td>. $row['pan_no'] .</td></tr>
    <tr><th>Function</th><td>. $row['function'] .</td></tr>
    <tr><th>Designation</th><td>. $row['designation'] .</td></tr>
    <tr><th>Remark</th><td>. $row['remark'] .</td></tr>
    <tr><th>Blood Group</th><td>. $row['blood_group'] .</td></tr>
    <tr><th>Nationality</th><td>. $row['nationality'] .</td></tr>
    <tr><th>Residential Address</th><td>. $row['residential_address'] .</td></tr>
    <tr><th>Correspondence Address</th><td>. $row['correspondence_address'] .</td></tr>
    <tr><th>Login Id</th><td>. $row['login_id'] .</td></tr>
    <tr><th>Password</th><td>. $row['password'] .</td></tr>
    <tr><th>Left Date</th><td>. $row['left_date'] .</td></tr>
    <tr><th>Status</th><td>. $row['status'] .</td></tr>
    <tr><th>Type</th><td>. $row['employee_type'] .</td></tr>
    <img class="img-responsive image_on_modal" src=". base_url()./uploads/. $row['employee_image'] .">
</table>